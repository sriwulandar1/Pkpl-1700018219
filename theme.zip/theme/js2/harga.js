<script type='text/javascript'>
    function layanan() {
    // <!--Deklarasi Variabel-->
    var layanan = (document.form.layanan.value);
    // < !--Nilai Variabel(tujuan) diambil dari Form input yang bernama(input_tujuan) -- >
    // !--Selesai Deklarasi Variabel-- >

    if (layanan == "web") {
        var paket;
        if (paket == "Basic") {
        harga = 2000000;
        } else if (paket == "Premium") {
        harga = 3000000;
        } else if (paket == "Bisnis") {
        harga = 4000000;
        } else if (paket == "ultimate") {
        harga = 5000000;
        }


        document.form.output_harga.value = eval(harga);
    } else if (layanan == "hosting") {
        var paket;
        if (paket == "Basic") {
        harga = 200000;
        } else if (paket == "Premium") {
        harga = 300000;
        } else if (paket == "Bisnis") {
        harga = 400000;
        } else if (paket == "ultimate") {
        harga = 500000;
        }


        document.form.output_harga.value = eval(harga);
    }
</script>