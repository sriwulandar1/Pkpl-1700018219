<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Order extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Visitor_model', 'visitor_model');
        $this->load->model('Home_model', 'home_model');
        $this->load->model('Site_model', 'site_model');
        $this->visitor_model->count_visitor();
        $this->load->helper('text');
    }

    function cek_domain()
    {
        //$this->output->enable_profiler(TRUE);
        $site_info = $this->db->get('tbl_site', 1)->row();

        $v['logo'] =  $site_info->site_logo_header;
        $data['icon'] = $site_info->site_favicon;
        if (isset($_POST['cek'])) {
            $nama_domain = "$_POST[domain]" . "$_POST[ext]";
            $url = "https://order2.rumahweb.com/order/siapa/domain/" . $nama_domain;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "$url");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $output = curl_exec($ch);
            $data = json_decode($output, true);
            if ($output != "Domain Unavailable") {
                //$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">Domain Anda Tersedia.</div>');
                $this->session->set_flashdata('domain', $nama_domain);
                redirect('order/order_web');
            } else {
                $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Domain anda tidak tersedia.</div>');
                redirect('order/cek_domain');
            }
        }
        $data['header'] = $this->load->view('header', $v, TRUE);
        $data['footer'] = $this->load->view('footer', '', TRUE);
        $this->load->view('cek_domain_view', $data);
    }
    function order_web()
    {
        //$this->output->enable_profiler(TRUE);

        $this->form_validation->set_rules('nama', 'Name', 'required');
        $this->form_validation->set_rules('email', 'E-mail', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[5]');
        $this->form_validation->set_rules('domain', 'Domain', 'required');
        $this->form_validation->set_rules('paket', 'Packet', 'required');
        $this->form_validation->set_rules('layanan', 'Service', 'required');
        $this->form_validation->set_rules('telpon', 'Telphone', 'required');
        $this->load->helper('string');
        $id_pesanan = random_string('alnum', 10);
        $layanan = $this->input->post('layanan');
        $paket = $this->input->post('paket');
        if ($layanan == "web") {
            if ($paket == "basic") {
                $harga = 1000000;
            } else if ($paket == "premium") {
                $harga = 2000000;
            } else if ($paket == "bisnis") {
                $harga = 3000000;
            } else if ($paket == "ultimate") {
                $harga = 4000000;
            }
        } elseif ($layanan == "hosting") {
            if ($paket == "basic") {
                $harga = 100000;
            } else if ($paket == "premium") {
                $harga = 200000;
            } else if ($paket == "bisnis") {
                $harga = 300000;
            } else if ($paket == "ultimate") {
                $harga = 400000;
            }
        }
        if ($this->form_validation->run() == false) {
            $site_info = $this->db->get('tbl_site', 1)->row();
            $v['logo'] =  $site_info->site_logo_header;
            $data['icon'] = $site_info->site_favicon;
            $data['header'] = $this->load->view('header', $v, TRUE);
            $data['footer'] = $this->load->view('footer', '', TRUE);
            $this->load->view('order_web_view', $data);
        } else {

            $data = [
                'id_pesanan' => $id_pesanan,
                'nama' => htmlspecialchars($this->input->post('nama'), true),
                'email' => htmlspecialchars($this->input->post('email'), true),
                'password' => htmlspecialchars($this->input->post('password'), true),
                'domain' => htmlspecialchars($this->input->post('domain'), true),
                'paket' => htmlspecialchars($this->input->post('paket'), true),
                'layanan' => htmlspecialchars($this->input->post('layanan'), true),
                'telpon' => htmlspecialchars($this->input->post('telpon'), true),
                'total_harga' => $harga,
                'konfirmasi' => 0,
                'tanggal' => time()

            ];
            $this->db->insert('tbl_pemesanan_web', $data);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">Selamat Pesanan Anda telah didaftarkan. silahkan klik <a href="status_web">link ini</a> untuk cek status pesanan </div>');
            redirect('order/order_web');
        }
    }
    public function status_web()
    {
        //$this->output->enable_profiler(TRUE);
        $site_info = $this->db->get('tbl_site', 1)->row();

        $v['logo'] =  $site_info->site_logo_header;
        $data['icon'] = $site_info->site_favicon;
        $id = $this->input->post('id_pesanan');
        $data['pesanan'] = $this->db->get_where('tbl_pemesanan_web', ['id_pesanan' => $id])->row_array();
        $data['header'] = $this->load->view('header', $v, TRUE);
        $data['footer'] = $this->load->view('footer', '', TRUE);
        $this->load->view('status_web_view', $data);
    }
}
