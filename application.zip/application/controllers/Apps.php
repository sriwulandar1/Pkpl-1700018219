<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Apps extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Visitor_model', 'visitor_model');
        $this->load->model('Home_model', 'home_model');
        $this->load->model('Site_model', 'site_model');
        $this->visitor_model->count_visitor();
        $this->load->helper('text');
    }
    function index()
    {
        //$this->output->enable_profiler(TRUE);
        //$this->output->enable_profiler(TRUE);

        $this->form_validation->set_rules('nama', 'Name', 'required');
        $this->form_validation->set_rules('email', 'E-mail', 'required');
        $this->form_validation->set_rules('alamat', 'Address', 'required');
        $this->form_validation->set_rules('layanan', 'Service', 'required');
        $this->form_validation->set_rules('telpon', 'Telphone', 'required');
        $this->load->helper('string');
        $id_pesanan = random_string('alnum', 10);

        if ($this->form_validation->run() == false) {
            $site_info = $this->db->get('tbl_site', 1)->row();
            $v['logo'] =  $site_info->site_logo_header;
            $data['icon'] = $site_info->site_favicon;
            $data['header'] = $this->load->view('header', $v, TRUE);
            $data['footer'] = $this->load->view('footer', '', TRUE);
            $this->load->view('order_apps_view', $data);
        } else {

            $data = [
                'id_pesanan' => $id_pesanan,
                'nama' => htmlspecialchars($this->input->post('nama'), true),
                'email' => htmlspecialchars($this->input->post('email'), true),
                'alamat' => htmlspecialchars($this->input->post('alamat'), true),
                'layanan' => htmlspecialchars($this->input->post('layanan'), true),
                'telpon' => htmlspecialchars($this->input->post('telpon'), true),
                'harga' => 0,
                'konfirmasi' => 0,
                'tanggal' => time()

            ];
            $this->db->insert('tbl_pemesanan_apps', $data);
            $this->session->set_flashdata('id', $data['id_pesanan']);
            $this->session->set_flashdata('nama', $data['nama']);
            $this->session->set_flashdata('email', $data['email']);
            $this->session->set_flashdata('domain', $data['domain']);
            $this->session->set_flashdata('layanan', $data['layanan']);
            $this->session->set_flashdata('alamat', $data['alamat']);
            $this->session->set_flashdata('telpon', $data['telpon']);
            $this->session->set_flashdata('konfirmasi', $data['konfirmasi']);
            $this->session->set_flashdata('harga', $data['harga']);
            $this->session->set_flashdata('tanggal', $data['tanggal']);
            redirect('apps/struk');
        }
    }


    public function status()
    {
        //$this->output->enable_profiler(TRUE);
        $site_info = $this->db->get('tbl_site', 1)->row();

        $v['logo'] =  $site_info->site_logo_header;
        $data['icon'] = $site_info->site_favicon;
        $id = $this->input->post('id_pesanan');
        $data['pesanan'] = $this->db->get_where('tbl_pemesanan_apps', ['id_pesanan' => $id])->row_array();
        $data['header'] = $this->load->view('header', $v, TRUE);
        $data['footer'] = $this->load->view('footer', '', TRUE);
        $this->load->view('status_apps_view', $data);
    }
    public function struk()
    {
        //$this->output->enable_profiler(TRUE);
        $site_info = $this->db->get('tbl_site', 1)->row();

        $v['logo'] =  $site_info->site_logo_header;
        $data['icon'] = $site_info->site_favicon;
        $data['header'] = $this->load->view('header', $v, TRUE);
        $data['footer'] = $this->load->view('footer', '', TRUE);
        $this->load->view('struk_apps_view', $data);
    }
}
