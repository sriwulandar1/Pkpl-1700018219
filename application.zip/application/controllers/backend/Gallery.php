<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Gallery extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('logged') != TRUE) {
            $url = base_url('administrator');
            redirect($url);
        };
        $this->load->model('backend/Inbox_model', 'inbox_model');
        error_reporting(0);
        $this->load->helper('text');
    }

    function index()
    {

        $data['galery'] =  $this->db->get('tbl_galery')->result_array();
        //view
        $this->load->view('backend/v_gallery', $data);
    }
    public function tambah()
    {
        $data['galery'] =  $this->db->get('tbl_galery')->result_array();
        $this->load->view('backend/v_gallery', $data);
        //cek gambar yang akan diupload
        $upload_image = $_FILES['gambar']['name'];
        if ($upload_image) {
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size']     = '2048';
            $config['upload_path'] = './assets/images/galery/foto/';
            $this->load->library('upload', $config);
            if ($this->upload->do_upload('gambar')) {
                $old_image = $data['user']['gambar'];
                if ($old_image != 'default.jpg') {
                    unlink(FCPATH . '/assets/images/galery/foto/' . $old_image);
                }
                $new_image = $this->upload->data('file_name');
            } else {
                echo $this->upload->display_errors();
            }
        }
        $data = [
            'nama_gambar' => $new_image,
        ];
        $this->db->insert('tbl_galery', $data);
        redirect('backend/gallery');
    }
    public function hapus($id)
    {
        $this->db->where('id_gambar', $id);
        $this->db->delete('tbl_galery');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Menu Telah Dihapus</div>');
        redirect('backend/gallery');
    }
}
