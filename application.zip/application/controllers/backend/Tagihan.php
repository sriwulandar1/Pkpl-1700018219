<?php

/**
 * @package			Codeigniter
 * @author      	Yulius
 * @license 		http://codeigniter.com/user_guide/license.html
 * @since 			Version 3.1.4
 */


// ------------------------------------------------------------------------

/**
 *	Application Controller Class Invoice extends MY_Controller
 * 
 *	Class ini untuk halaman tagihan
 *
 *	@subpackage			model, view
 */

defined('BASEPATH') or exit('No direct script access allowed');

class Tagihan extends CI_Controller
{


    // Konstruktur
    function __construct()
    {


        parent::__construct();
        error_reporting(0);
        if ($this->session->userdata('logged') != TRUE) {
            $url = base_url('administrator');
            redirect($url);
        };

        $this->load->helper('text');
        $this->load->model('backend/Tagihan_model', 'tagihan_model');
    }

    // fungsi index
    public function index()
    {


        // view
        $this->load->view('backend/v_tagihan');
    }


    // fungsi data tagihan pending
    public function aplikasi()
    {
        $data['tagihanapps'] =  $this->db->get('tbl_pemesanan_apps')->result_array();
        //view
        $this->load->view('backend/v_tagihan_aplikasi', $data);
    }
    public function aplikasi_hapus($id)
    {
        $this->db->where('id_pesanan', $id);
        $this->db->delete('tbl_pemesanan_apps');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Menu Telah Dihapus</div>');
        redirect('backend/tagihan/aplikasi');
    }
    public function aplikasi_ubah($id)
    {
        $data['pesanan'] = $this->db->get_where('tbl_pemesanan_apps', ['id_pesanan' => $id])->row_array();
        $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('layanan', 'layanan', 'required');
        $this->form_validation->set_rules('telpon', 'telpon', 'required');
        $this->form_validation->set_rules('harga', 'harga', 'required');
        $this->form_validation->set_rules('konfirmasi', 'status', 'required');
        if ($this->form_validation->run() == false) {
            $this->load->view('backend/v_tagihan_aplikasi_ubah', $data);
        } else {
            $data = [
                'nama' => htmlspecialchars($this->input->post('nama'), true),
                'email' => htmlspecialchars($this->input->post('email'), true),
                'alamat' => htmlspecialchars($this->input->post('alamat'), true),
                'layanan' => htmlspecialchars($this->input->post('layanan'), true),
                'telpon' => htmlspecialchars($this->input->post('telpon'), true),
                'harga' => htmlspecialchars($this->input->post('harga'), true),
                'konfirmasi' => htmlspecialchars($this->input->post('konfirmasi'), true)
            ];
            $this->db->where('id_pesanan', $id);
            $this->db->update('tbl_pemesanan_apps', $data);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">subMenu Telah Diubah</div>');
            redirect('backend/tagihan/aplikasi');
        }
    }
    public function mulmed()
    {
        $data['tagihanmulmed'] =  $this->db->get('tbl_pemesanan_mulmed')->result_array();
        //view
        $this->load->view('backend/v_tagihan_mulmed', $data);
    }
    public function mulmed_hapus($id)
    {
        $this->db->where('id_pesanan', $id);
        $this->db->delete('tbl_pemesanan_mulmed');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Menu Telah Dihapus</div>');
        redirect('backend/tagihan/mulmed');
    }
    public function mulmed_ubah($id)
    {

        $data['pesanan'] = $this->db->get_where('tbl_pemesanan_mulmed', ['id_pesanan' => $id])->row_array();
        $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('layanan', 'layanan', 'required');
        $this->form_validation->set_rules('telpon', 'telpon', 'required');
        $this->form_validation->set_rules('harga', 'harga', 'required');
        $this->form_validation->set_rules('konfirmasi', 'status', 'required');
        if ($this->form_validation->run() == false) {
            $this->load->view('backend/v_tagihan_mulmed_ubah', $data);
        } else {
            $data = [
                'nama' => htmlspecialchars($this->input->post('nama'), true),
                'email' => htmlspecialchars($this->input->post('email'), true),
                'alamat' => htmlspecialchars($this->input->post('alamat'), true),
                'layanan' => htmlspecialchars($this->input->post('layanan'), true),
                'telpon' => htmlspecialchars($this->input->post('telpon'), true),
                'harga' => htmlspecialchars($this->input->post('harga'), true),
                'konfirmasi' => htmlspecialchars($this->input->post('konfirmasi'), true)
            ];
            $this->db->where('id_pesanan', $id);
            $this->db->update('tbl_pemesanan_mulmed', $data);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">subMenu Telah Diubah</div>');
            redirect('backend/tagihan/mulmed');
        }
    }
    public function hosting_domain()
    {
        $data['tagihanhostingdomain'] =  $this->db->get('tbl_pemesanan_hosting_domain')->result_array();
        //view
        $this->load->view('backend/v_tagihan_hosting_domain', $data);
    }
    public function hosting_domain_ubah($id)
    {

        $data['pesanan'] = $this->db->get_where('tbl_pemesanan_hosting_domain', ['id_pesanan' => $id])->row_array();
        $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('domain', 'Domain', 'required');
        $this->form_validation->set_rules('layanan', 'layanan', 'required');
        $this->form_validation->set_rules('telpon', 'telpon', 'required');
        $this->form_validation->set_rules('harga', 'harga', 'required');
        $this->form_validation->set_rules('konfirmasi', 'status', 'required');
        if ($this->form_validation->run() == false) {
            $this->load->view('backend/v_tagihan_hosting_domain_ubah', $data);
        } else {
            $data = [
                'nama' => htmlspecialchars($this->input->post('nama'), true),
                'email' => htmlspecialchars($this->input->post('email'), true),
                'password' => htmlspecialchars($this->input->post('password'), true),
                'alamat' => htmlspecialchars($this->input->post('alamat'), true),
                'layanan' => htmlspecialchars($this->input->post('layanan'), true),
                'telpon' => htmlspecialchars($this->input->post('telpon'), true),
                'harga' => htmlspecialchars($this->input->post('harga'), true),
                'konfirmasi' => htmlspecialchars($this->input->post('konfirmasi'), true)
            ];
            $this->db->where('id_pesanan', $id);
            $this->db->update('tbl_pemesanan_hosting_domain', $data);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">subMenu Telah Diubah</div>');
            redirect('backend/tagihan/hosting_domain');
        }
    }
    public function hosting_domain_hapus($id)
    {
        $this->db->where('id_pesanan', $id);
        $this->db->delete('tbl_pemesanan_hosting_domain');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Menu Telah Dihapus</div>');
        redirect('backend/tagihan/hosting_domain');
    }
    public function email_vps()
    {
        $data['tagihanemailvps'] =  $this->db->get('tbl_pemesanan_email_vps')->result_array();
        //view
        $this->load->view('backend/v_tagihan_email_vps', $data);
    }
    public function email_vps_ubah($id)
    {

        $data['pesanan'] = $this->db->get_where('tbl_pemesanan_email_vps', ['id_pesanan' => $id])->row_array();
        $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('layanan', 'layanan', 'required');
        $this->form_validation->set_rules('telpon', 'telpon', 'required');
        $this->form_validation->set_rules('harga', 'harga', 'required');
        $this->form_validation->set_rules('konfirmasi', 'status', 'required');
        if ($this->form_validation->run() == false) {
            $this->load->view('backend/v_tagihan_email_vps_ubah', $data);
        } else {
            $data = [
                'nama' => htmlspecialchars($this->input->post('nama'), true),
                'email' => htmlspecialchars($this->input->post('email'), true),
                'password' => htmlspecialchars($this->input->post('password'), true),
                'alamat' => htmlspecialchars($this->input->post('alamat'), true),
                'layanan' => htmlspecialchars($this->input->post('layanan'), true),
                'telpon' => htmlspecialchars($this->input->post('telpon'), true),
                'harga' => htmlspecialchars($this->input->post('harga'), true),
                'konfirmasi' => htmlspecialchars($this->input->post('konfirmasi'), true)
            ];
            $this->db->where('id_pesanan', $id);
            $this->db->update('tbl_pemesanan_email_vps', $data);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">subMenu Telah Diubah</div>');
            redirect('backend/tagihan/email_vps');
        }
    }
    public function email_vps_hapus($id)
    {
        $this->db->where('id_pesanan', $id);
        $this->db->delete('tbl_pemesanan_email_vps');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Menu Telah Dihapus</div>');
        redirect('backend/tagihan/email_vps');
    }
}
