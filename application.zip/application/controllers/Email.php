<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Email extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Visitor_model', 'visitor_model');
        $this->load->model('Home_model', 'home_model');
        $this->load->model('Site_model', 'site_model');
        $this->visitor_model->count_visitor();
        $this->load->helper('text');
    }
    function index()
    {
        //$this->output->enable_profiler(TRUE);
        $site = $this->site_model->get_site_data()->row_array();
        $data['site_name'] = $site['site_name'];
        $data['site_title'] = $site['site_title'];
        $data['site_desc'] = $site['site_description'];
        $data['site_twitter'] = $site['site_twitter'];
        $data['site_image'] = $site['site_logo_big'];
        $data['post_header'] = $this->home_model->get_post_header();
        $data['post_header_2'] = $this->home_model->get_post_header_2();
        $data['post_header_3'] = $this->home_model->get_post_header_3();
        $data['latest_post'] = $this->home_model->get_latest_post();
        $data['popular_post'] = $this->home_model->get_popular_post();
        $home = $this->db->get('tbl_home', 1)->row();
        $data['caption_1'] = $home->home_caption_1;
        $data['caption_2'] = $home->home_caption_2;
        $data['bg_header'] = $home->home_bg_heading;
        $data['bg_testimoni'] = $home->home_bg_testimonial;
        $data['testimonial'] = $this->db->get('tbl_testimonial');
        $site_info = $this->db->get('tbl_site', 1)->row();
        $v['logo'] =  $site_info->site_logo_header;
        $data['icon'] = $site_info->site_favicon;
        $data['header'] = $this->load->view('header', $v, TRUE);
        $data['footer'] = $this->load->view('footer', '', TRUE);
        $this->load->view('emailhosting', $data);
    }
    public function order()
    {
        //$this->output->enable_profiler(TRUE);

        $this->form_validation->set_rules('nama', 'Name', 'required');
        $this->form_validation->set_rules('email', 'E-mail', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[5]');
        $this->form_validation->set_rules('paket', 'Packet', 'required');
        $this->form_validation->set_rules('alamat', 'Address', 'required');
        $this->form_validation->set_rules('layanan', 'Service', 'required');
        $this->form_validation->set_rules('telpon', 'Telphone', 'required');
        $this->load->helper('string');
        $id_pesanan = random_string('alnum', 10);

        $paket = $this->input->post('paket');


        if ($paket == "mail pro") {
            $harga = 89600;
        } else if ($paket == "mail business") {
            $harga = 134640;
        } else if ($paket == "mail business extra") {
            $harga = 201960;
        }



        if ($this->form_validation->run() == false) {
            $site_info = $this->db->get('tbl_site', 1)->row();
            $v['logo'] =  $site_info->site_logo_header;
            $data['icon'] = $site_info->site_favicon;
            $data['header'] = $this->load->view('header', $v, TRUE);
            $data['footer'] = $this->load->view('footer', '', TRUE);
            $this->load->view('order_email_view', $data);
        } else {

            $data = [
                'id_pesanan' => $id_pesanan,
                'nama' => htmlspecialchars($this->input->post('nama'), true),
                'email' => htmlspecialchars($this->input->post('email'), true),
                'password' => htmlspecialchars($this->input->post('password'), true),
                'paket' => htmlspecialchars($this->input->post('paket'), true),
                'alamat' => htmlspecialchars($this->input->post('alamat'), true),
                'layanan' => htmlspecialchars($this->input->post('layanan'), true),
                'telpon' => htmlspecialchars($this->input->post('telpon'), true),
                'harga' => $harga,
                'konfirmasi' => 0,
                'tanggal' => time()

            ];
            $this->db->insert('tbl_pemesanan_email_vps', $data);
            $this->session->set_flashdata('id', $data['id_pesanan']);
            $this->session->set_flashdata('nama', $data['nama']);
            $this->session->set_flashdata('email', $data['email']);
            $this->session->set_flashdata('paket', $data['paket']);
            $this->session->set_flashdata('layanan', $data['layanan']);
            $this->session->set_flashdata('alamat', $data['alamat']);
            $this->session->set_flashdata('telpon', $data['telpon']);
            $this->session->set_flashdata('konfirmasi', $data['konfirmasi']);
            $this->session->set_flashdata('harga', $data['harga']);
            $this->session->set_flashdata('tanggal', $data['tanggal']);

            redirect('email/struk');
        }
    }
    public function status()
    {
        //$this->output->enable_profiler(TRUE);
        $site_info = $this->db->get('tbl_site', 1)->row();

        $v['logo'] =  $site_info->site_logo_header;
        $data['icon'] = $site_info->site_favicon;
        $id = $this->input->post('id_pesanan');
        $data['pesanan'] = $this->db->get_where('tbl_pemesanan_email_vps', ['id_pesanan' => $id])->row_array();
        $data['header'] = $this->load->view('header', $v, TRUE);
        $data['footer'] = $this->load->view('footer', '', TRUE);
        $this->load->view('status_email_view', $data);
    }
    public function struk()
    {
        //$this->output->enable_profiler(TRUE);
        $site_info = $this->db->get('tbl_site', 1)->row();

        $v['logo'] =  $site_info->site_logo_header;
        $data['icon'] = $site_info->site_favicon;
        $data['header'] = $this->load->view('header', $v, TRUE);
        $data['footer'] = $this->load->view('footer', '', TRUE);
        $this->load->view('struk_email_view', $data);
    }
}
