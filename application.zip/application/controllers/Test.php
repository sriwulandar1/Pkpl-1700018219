<?php
class Test extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Tag_model', 'tag_model');
        $this->load->model('Blog_model', 'blog_model');
        $this->load->model('Visitor_model', 'visitor_model');
        $this->load->model('Site_model', 'site_model');
        $this->visitor_model->count_visitor();
        $this->load->helper('text');
        error_reporting(0);
    }

    function index()
    {
        $this->load->helper('string');
        $id_pesanan = random_string('alnum', 10);
        echo $id_pesanan;
    }
}
