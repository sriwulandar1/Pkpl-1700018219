<!DOCTYPE html>
<html lang="en">

<head>

	<!-- Page Title -->
	<title><?php echo $site_title; ?></title>

	<!-- Page header -->
	<meta charset="utf-8" />
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />
	<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
	<meta name="viewport" content="width=device-width" />
	<!-- CSS -->
	<link rel="stylesheet" href="<?php echo base_url('theme/css/bootstrap.min.css') ?>" />
	<link rel="stylesheet" href="<?php echo base_url('theme/css/style.css') ?>" />
	<link rel="stylesheet" href="<?php echo base_url('theme/css/padding-margin.css') ?>" />
	<!-- Favicons -->
	<link rel="shortcut icon" href="<?php echo base_url('theme/images/' . $icon); ?>">
	<!-- SEO Tag -->
	<meta name="description" content="<?php echo $site_desc; ?>" />
	<link rel="canonical" href="<?php echo site_url(); ?>" />
	<meta property="og:locale" content="id_ID" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="<?php echo $site_title; ?>" />
	<meta property="og:description" content="<?php echo $site_desc; ?>" />
	<meta property="og:url" content="<?php echo site_url(); ?>" />
	<meta property="og:site_name" content="<?php echo $site_name; ?>" />
	<meta property="og:image" content="<?php echo base_url() . 'theme/images/' . $site_image ?>" />
	<meta property="og:image:secure_url" content="<?php echo base_url() . 'theme/images/' . $site_image ?>" />
	<meta property="og:image:width" content="560" />
	<meta property="og:image:height" content="315" />
	<meta name="twitter:card" content="summary" />
	<meta name="twitter:description" content="<?php echo $site_desc; ?>" />
	<meta name="twitter:title" content="<?php echo $site_title; ?>" />
	<meta name="twitter:site" content="<?php echo $site_twitter; ?>" />
	<meta name="twitter:image" content="<?php echo base_url() . 'theme/images/' . $site_image ?>" />
	<link rel="stylesheet" href="<?php echo base_url() . 'theme/css/font-awesome.min.css' ?>" />
	<!-- End SEO Tag. -->
	<!-- fitur -->
	<!-- Animate.css -->
	<link rel="stylesheet" href="<?php echo base_url() . 'theme/css2/animate.css' ?>">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="<?php echo base_url() . 'theme/css2/icomoon.css' ?>">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="<?php echo base_url() . 'theme/css2/bootstrap.css' ?>">
	<!-- Flexslider  -->
	<link rel="stylesheet" href="<?php echo base_url() . 'theme/css2/flexslider.css' ?>">
	<!-- Theme style  -->
	<link rel="stylesheet" href="<?php echo base_url() . 'theme/css2/style.css' ?>">

	<!-- logo -->
	<!-- Custom fonts for this template -->
	<link href="<?php echo base_url() . 'assets/v2/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css' ?>">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
	<link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

	<!-- Custom styles for this template -->
	<link href="v2/css/agency.min.css" rel="stylesheet">



	<!-- Bootstrap CSS-->
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/vendor/bootstrap/css/bootstrap.min.css' ?>">
	<!-- Font Awesome CSS-->
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/vendor/font-awesome/css/font-awesome.min.css' ?>">
	<!-- Google fonts - Roboto + Roboto Slab-->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,700%7CRoboto:400,700,300">
	<!-- owl carousel-->
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/vendor/owl.carousel/assets/owl.carousel.css' ?>">
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/vendor/owl.carousel/assets/owl.theme.default.css' ?>">
	<!-- animate.css-->
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/vendor/animate.css/animate.css' ?>">
	<!-- theme stylesheet-->
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/style.default.css" id="theme-stylesheet' ?>">
	<!-- Custom stylesheet - for your changes-->
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/custom.css' ?>">
	<!-- Leaflet CSS - For the map-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.4.0/leaflet.css">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/favicon.png">
	<!-- Tweaks for older IEs-->
	<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>

<body class="content-animate">

	<!-- PRELOADER
		==================================================-->
	<div class="page-loader">
		<div class="loader-area"></div>
		<div class="loader font-face1">loading...
		</div>
	</div>
	<!-- PAGE
		==================================================-->
	<div id="top" class="page">

		<!-- Navigation panel
			================================================== -->
		<?php echo $header; ?>
		<!-- End Navigation panel -->

		<!-- Main Content
			==================================================-->
		<main class="cd-main-content">

			<!-- HOME SECTION
				================================================== -->
			<section id="homepage" class="home page-section parallax-2 overlay-light-alpha-10" data-background="<?php echo base_url() . 'theme/images/' . $bg_header; ?>">
				<div class="table-content">
					<div class="table-center-text">
						<div class="container" align="right">
							<h2 class="font-face1 heading1 fw700 mb-40 mb-xs-30"><?php echo $caption_1; ?></h2>
							<h1 class="font-face1 heading2 fw700 mb-40 mb-xs-30"><?php echo $caption_2; ?></h1>
							<div class="local-scroll">


								<!--<a href="<?php echo site_url('pemesanan'); ?>" class="btn bg-black white-color">Pemesanan Sekarang</a>
								<span class="btn_seperator"></span>-->
								<!--<a href="<?php echo site_url('blog'); ?>" class="btn bg-black whitre-color hidden-xs">Blog</a>-->
							</div>
							<!-- timer promo -->
							<style scoped="scoped" type="text/css">
								#countdownpenaindigo {
									background: ;
									color: white;
									font-family: Oswald, Arial, Sans-serif;
									font-size: 40px;
									text-transform: uppercase;
									text-align: left;
									margin-top: 500px;
									font-weight: normal;

								}

								.teks {
									color: black;
									font-size: 10px;
								}

								.posisi {
									position: relative;
								}
							</style>
							<div id="countdownpenaindigo">
								<h1 style="color: black;font-size: 13px;"><strong>Yuk buruan order promonya sebelum kehabisan!</strong></h1>
								<span id="countdown"></span>&nbsp;
								<a href="<?php echo site_url('hosting'); ?>" class="btn bg-black white-color ">Pesan Sekarang</a>
								<span class="btn_seperator"></span>
							</div>
							<script type="text/javascript">
								//<![CDATA[
								// set the date we're counting down to
								var target_date = new Date("Nov 1, 2020").getTime();
								// variables for time units
								var days, hours, minutes, seconds;
								// get tag element
								var countdown = document.getElementById("countdown");
								// update the tag with id "countdown" every 1 second
								setInterval(function() {
									// find the amount of "seconds" between now and target
									var current_date = new Date().getTime();
									var seconds_left = (target_date - current_date) / 1000;
									// do some time calculations
									days = parseInt(seconds_left / 86400);
									seconds_left = seconds_left % 86400;
									hours = parseInt(seconds_left / 3600);
									seconds_left = seconds_left % 3600;
									minutes = parseInt(seconds_left / 60);
									seconds = parseInt(seconds_left % 60);
									// format countdown string + set tag value

									countdown.innerHTML = days + " <span class='teks'>hari</span> " + hours + " <span class='teks'>jam</span> " +
										minutes + " <span class='teks'>menit</span> " + seconds + " <span class='teks'>detik </span>";
								}, 1000);
								//]]>
							</script>
						</div>
					</div>
				</div>
			</section>


			<!-- paket hosting -->
			<style>
				.jarak {
					margin-top: 50px;
					margin-bottom: 30px;
				}

				.coba {
					margin-bottom: 100px;
				}
			</style>
			<!-- feature_part start-->
			<link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/bootstrap.min.css">
			<!-- animate CSS -->
			<link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/animate.css">
			<!-- owl carousel CSS -->
			<link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/owl.carousel.min.css">
			<!-- themify CSS -->
			<link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/themify-icons.css">
			<!-- flaticon CSS -->
			<link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/flaticon.css">
			<!-- font awesome CSS -->
			<link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/font-awesome.min.css" />
			<!-- swiper CSS -->
			<link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/slick.css">
			<!-- style CSS -->
			<link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/style.css">
			<section class="feature_part">
				<div class="container">
					<center>
						<div>
							<div class="single_feature_text coba">
								<h2>Fitur Layanan Kami</h2>
								<!--<p>Fitur pelayanan dari kami yang dapat anda nikmati, agar rumah anda menjadi bersih dan nyaman. </p>-->
								<!--<a href="#" class="btn_1">Read More</a>-->
							</div>
					</center>
					<a href="<?= base_url(); ?>hosting">
						<div class="col-sm-6 col-xl-3">
							<div class="single_feature">
								<div class="single_feature_part">
									<span class="single_feature_icon">
										<img style="margin-bottom: 10px" src="<?= base_url(); ?>assets/images/logowebHDD.png" width="35px" height="35px">
									</span>
									<h4>Unlimited Hosting</h4>
									<p>Cocok untuk website pada tingkat menengah</p>
								</div>
							</div>
						</div>
						<a href="<?= base_url(); ?>vps">
							<div class="col-sm-6 col-xl-3">
								<div class="single_feature">
									<div class="single_feature_part">
										<span class="single_feature_icon style_icon">
											<img style="margin-bottom: 10px" src="assets/images/logowebVPS.png" width="35px" height="35px">
										</span>
										<h4>Cloud VPS</h4>
										<p>Dedicated resource dengan akses root dan konfigurasi </p>
									</div>
								</div>
							</div>
							<a href="<?= base_url(); ?>email">
								<div class="col-sm-6 col-xl-3">
									<div class="single_feature">
										<div class="single_feature_part single_feature_part_2">
											<span class="single_feature_icon style_icon">
												<img style="margin-bottom: 10px" src="assets/images/logowebMail.png" width="35px" height="35px"></span>
											<h4>Email Hosting</h4>
											<p>cocok untuk perusahaan atau perguruan tinggi</p>
										</div>
									</div>
								</div>
								<a href="<?= base_url(); ?>domain">
									<div class="col-sm-6 col-xl-3 coba">
										<div class="single_feature">
											<div class="single_feature_part single_feature_part_2">
												<span class="single_feature_icon style_icon">
													<img style="margin-bottom: 10px" src="assets/images/logowebdomain.png" width="35px" height="35px"></span>
												<h4>Domain</h4>
												<p>temukan domain kesayangan anda</p>
											</div>
										</div>
									</div>
				</div>
	</div>
	</section>
	<!-- end -->

	<!-- fitur -->
	<div id="fh5co-why-us" class="animate-box">
		<div class="container">
			<div class="row">
				<div class="col-md-4 text-center item-block">
					<span class="icon"><img src="<?php echo base_url() . 'theme/images/ww.png' ?>" class="img-responsive"></span>
					<h3>BUILD WEBSITE</h3>
					<p>Tingkatkan kinerja bisnis dan usaha anda di dunia Internet melalui Website.</p>
					<p><a href="apps" class="btn btn-primary btn-outline with-arrow">Learn more</a></p>
				</div>
				<div class="col-md-4 text-center item-block">
					<span class="icon"><img src="<?php echo base_url() . 'theme/images/desain.png' ?>" class="img-responsive"></span>
					<h3>MAKE GRAPHIC DESIGN</h3>
					<p>Bangun desain dan logo perusahaan anda melalui pelayanan kami.</p>
					<p><a href="multimedia" class="btn btn-primary btn-outline with-arrow">Learn more</a></p>
				</div>
				<div class="col-md-4 text-center item-block">
					<span class="icon"><img src="<?php echo base_url() . 'theme/images/mobile.png' ?>" class="img-responsive"></span>
					<h3>BUILD MOBILE APPLICATION</h3>
					<p>Bangun identitas bisnis dan usaha anda di dunia Software melalui Mobile Application.</p>
					<p><a href="apps" class="btn btn-primary btn-outline with-arrow">Learn more</a></p>
				</div>
				<div class="col-md-4 text-center item-block">
					<span class="icon"><img src="<?php echo base_url() . 'theme/images/video1.png' ?>" class="img-responsive"></span>
					<h3>VIDEO EDITING</h3>
					<p>Bangun video perusahaan adan melalui pelayanan kami.</p>
					<p><a href="multimedia" class="btn btn-primary btn-outline with-arrow">Learn more</a></p>
				</div>
				<div class="col-md-4 text-center item-block">
					<span class="icon"><img src="<?php echo base_url() . 'theme/images/mobile.png' ?>" class="img-responsive"></span>
					<h3>ADS PROMOTION</h3>
					<p>Bangun identitas bisnis dan usaha anda di dunia periklanan untuk mendapatkan banyak pengunjung.</p>
					<p><a href="multimedia" class="btn btn-primary btn-outline with-arrow">Learn more</a></p>
				</div>
				<div class="col-md-4 text-center item-block">
					<span class="icon"><img src="<?php echo base_url() . 'theme/images/maintenance.png' ?>" class="img-responsive"></span>
					<h3>MAINTENANCE</h3>
					<p>pelihara website dan mobile aplication anda pada layanan kami selama 24 jam.</p>
					<p><a href="apps" class="btn btn-primary btn-outline with-arrow">Learn more</a></p>
				</div>
			</div>
		</div>
	</div>

	<!-- about -->
	<style>
		.hr {
			border: 0;
			height: 2px;
			background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));
		}

		.jarak {
			margin-top: 100px;
		}
	</style>

	<div class="site-section" id="section-about">
		<div class="container">
			<div class="row mb-5">

				<div class="col-md-5 ml-auto mb-5 order-md-2" data-aos="fade-up" data-aos-delay="100">
					<img src="<?php echo base_url() . 'assets/images/vps.png'; ?>" alt=" Image" class="img-fluid rounded">
				</div>
				<div class="col-md-6 order-md-1" data-aos="fade-up">
					<div class="text-left pb-1 border-primary mb-4">
						<h2 class="text-primary">Mengapa Memilih Kami ?</h2>
						<hr class="hr">
					</div>
					<p></p>
					<p class="mb-5">Karena di dalam perusahaan ini memliki fitur hosting, build website, build aplikasi hingga maintenance. Selain website anda terjamin aman dengan super extra,
						harga yang kami tawarkan juga murah. Jika anda mengalami kesulitan Tim Support kami akan membatu anda 24 jam hingga kesulitan anda terselesaikan.
					</p>

					<ul class="ul-check list-unstyled success">
						<li><svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-check2-circle" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" d="M15.354 2.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L8 9.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
								<path fill-rule="evenodd" d="M8 2.5A5.5 5.5 0 1 0 13.5 8a.5.5 0 0 1 1 0 6.5 6.5 0 1 1-3.25-5.63.5.5 0 1 1-.5.865A5.472 5.472 0 0 0 8 2.5z" />
							</svg>&nbsp Keamanan Website Super Extra</li>
						<li><svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-check2-circle" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" d="M15.354 2.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L8 9.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
								<path fill-rule="evenodd" d="M8 2.5A5.5 5.5 0 1 0 13.5 8a.5.5 0 0 1 1 0 6.5 6.5 0 1 1-3.25-5.63.5.5 0 1 1-.5.865A5.472 5.472 0 0 0 8 2.5z" />
							</svg>&nbsp Hosting Super Cepat</li>
						<li><svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-check2-circle" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" d="M15.354 2.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L8 9.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
								<path fill-rule="evenodd" d="M8 2.5A5.5 5.5 0 1 0 13.5 8a.5.5 0 0 1 1 0 6.5 6.5 0 1 1-3.25-5.63.5.5 0 1 1-.5.865A5.472 5.472 0 0 0 8 2.5z" />
							</svg>&nbsp Tim Support 24 jam</li>
						<li><svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-check2-circle" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" d="M15.354 2.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L8 9.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
								<path fill-rule="evenodd" d="M8 2.5A5.5 5.5 0 1 0 13.5 8a.5.5 0 0 1 1 0 6.5 6.5 0 1 1-3.25-5.63.5.5 0 1 1-.5.865A5.472 5.472 0 0 0 8 2.5z" />
							</svg>&nbsp Harga Murah dan Fitur lengkap</li>
						<li><svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-check2-circle" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" d="M15.354 2.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L8 9.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
								<path fill-rule="evenodd" d="M8 2.5A5.5 5.5 0 1 0 13.5 8a.5.5 0 0 1 1 0 6.5 6.5 0 1 1-3.25-5.63.5.5 0 1 1-.5.865A5.472 5.472 0 0 0 8 2.5z" />
							</svg>&nbsp Garansi 30 Hari</li>
						<li><svg width="1.5em" height="1.5em" viewBox="0 0 16 16" class="bi bi-check2-circle" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" d="M15.354 2.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L8 9.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
								<path fill-rule="evenodd" d="M8 2.5A5.5 5.5 0 1 0 13.5 8a.5.5 0 0 1 1 0 6.5 6.5 0 1 1-3.25-5.63.5.5 0 1 1-.5.865A5.472 5.472 0 0 0 8 2.5z" />
							</svg>&nbsp Website selalu online</li>
					</ul>

				</div>

			</div>
		</div>
	</div>
	<!-- end about -->

	<!-- logo -->
	<section id="customers" class="customers-section bg-gray jarak">
		<div class="container">
			<div class="text-center pb-1 border-primary mb-4">
				<h2 style="color: black;">Dipercaya 45.000+ Pelanggan di Seluruh Indonesia</h2>
				<hr class="hr">
			</div>
			<div class="col-md-8">

				<div class="row align-items-center">
					<div class="col-lg-2 col-md-8 col-sm-12">
						<div class="img"><a href="http://hrms.amnotel.co.id/"><img src="<?= base_url(); ?>assets/images/logo2.jpeg" title="Website Human Resource Management System Yogyakarta" data-placement="bottom" data-toggle="tooltip" alt="" class="img-fluid d-block mx-auto"></a></div>
					</div>
					<div class="col-lg-2 col-md-4 col-sm-6">
						<div class="customer"><a href="https://ppdbsmpitnuris.ga/"><img src="<?= base_url(); ?>assets/images/logo.jpeg" title="Website PPDB SMP IT Nurul Islam Yogyakarta" data-placement="bottom" data-toggle="tooltip" alt="" class="img-fluid d-block mx-auto"></a></div>
					</div>
					<div class="col-lg-2 col-md-4 col-sm-6">
						<div class="customer"><a href="http://srmtrans.com/"><img src="<?= base_url(); ?>assets/images/srm.png" title="Website Pemesanan Bus Pariwisata PT.SRM Trans Yogyakarta" data-placement="bottom" data-toggle="tooltip" alt="" class="img-fluid d-block mx-auto"></a></div>
					</div>
					<div class="col-lg-2 col-md-4 col-sm-6">
						<div class="customer"><a href="#"><img src="<?= base_url(); ?>assets/images/dadi resik.jpeg" title="Website Dadi Resik Sedot Tungau PT.Cakrawala Yogyakarta" data-placement="bottom" data-toggle="tooltip" alt="" class="img-fluid d-block mx-auto"></a></div>
					</div>
					<div class="col-lg-2 col-md-4 col-sm-6">
						<div class="customer"><a href="#"><img src="img/customers/laravel.png" title="Laravel" data-placement="bottom" data-toggle="tooltip" alt="" class="img-fluid d-block mx-auto"></a></div>
					</div>
					<div class="col-lg-2 col-md-4 col-sm-6">
						<div class="customer"><a href="#"><img src="img/customers/mongo.png" title="MongoDB" data-placement="bottom" data-toggle="tooltip" alt="" class="img-fluid d-block mx-auto"></a></div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- end -->


	<!-- SECTION SUBSCRIBE
				================================================== -->
	<section class="page-section subscribe-section small-section">
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="form-subscribe mb-50 mb-sm-0">
						<div class="col-sm-6 mb-sm-40">
							<h2 class="heading5 mt-0 font-face1 white-color fw700 mb-0">Newsletter.</h2>
						</div>
						<div class="col-sm-6">
							<form class="form-inline" action="<?php echo site_url('subscribe'); ?>" method="post">
								<div class="form-group">
									<input type="hidden" name="url" value="<?php echo site_url(); ?>" required>
									<input type="email" name="email" required placeholder="Your Email..." class="form-control">
									<button type="submit" class="btn btn-subscribe">Berlangganan</button>
								</div>
							</form>
						</div>
					</div>
					<div><?php echo $this->session->flashdata('message'); ?></div>
				</div>
			</div>
		</div>
	</section>
	<!-- end -->


	<!-- FOOTER
				================================================== -->
	<?php echo $footer; ?>

	</main>

	</div>

	<!-- Modal Search-->
	<div class="modal fade" id="ModalSearch" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="z-index: 10000;">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-body">
					<form action="<?php echo site_url('search'); ?>" method="GET">
						<div class="input-group">
							<input type="text" name="search_query" class="form-control input-search" style="height: 40px;" placeholder="Search..." required>
							<span class="input-group-btn">
								<button class="btn btn-default" type="submit" style="height: 40px;background-color: #ccc;"><span class="fa fa-search"></span></button>
							</span>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- JAVASCRIPT
		==================================================-->
	<script src="<?php echo base_url('theme/js/jquery-2.2.4.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/jquery.easing.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/bootstrap.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/waypoints.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/jquery.scrollTo.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/jquery.localScroll.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/jquery.viewport.mini.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/jquery.sticky.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/jquery.fitvids.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/jquery.parallax-1.1.3.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/isotope.pkgd.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/imagesloaded.pkgd.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/masonry.pkgd.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/jquery.magnific-popup.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/jquery.counterup.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/slick.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/wow.min.js') ?>"></script>
	<script src="<?php echo base_url('theme/js/script.js') ?>"></script>
</body>

</html>