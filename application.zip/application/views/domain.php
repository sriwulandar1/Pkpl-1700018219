<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Page Title -->
    <title><?php echo $site_title; ?></title>

    <!-- Page header -->
    <meta charset="utf-8" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="viewport" content="width=device-width" />
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo base_url('theme/css/bootstrap.min.css') ?>" />
    <link rel="stylesheet" href="<?php echo base_url('theme/css/style.css') ?>" />
    <link rel="stylesheet" href="<?php echo base_url('theme/css/padding-margin.css') ?>" />
    <!-- Favicons -->
    <link rel="shortcut icon" href="<?php echo base_url('theme/images/' . $icon); ?>">
    <!-- SEO Tag -->
    <meta name="description" content="<?php echo $site_desc; ?>" />
    <link rel="canonical" href="<?php echo site_url(); ?>" />
    <meta property="og:locale" content="id_ID" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php echo $site_title; ?>" />
    <meta property="og:description" content="<?php echo $site_desc; ?>" />
    <meta property="og:url" content="<?php echo site_url(); ?>" />
    <meta property="og:site_name" content="<?php echo $site_name; ?>" />
    <meta property="og:image" content="<?php echo base_url() . 'theme/images/' . $site_image ?>" />
    <meta property="og:image:secure_url" content="<?php echo base_url() . 'theme/images/' . $site_image ?>" />
    <meta property="og:image:width" content="560" />
    <meta property="og:image:height" content="315" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:description" content="<?php echo $site_desc; ?>" />
    <meta name="twitter:title" content="<?php echo $site_title; ?>" />
    <meta name="twitter:site" content="<?php echo $site_twitter; ?>" />
    <meta name="twitter:image" content="<?php echo base_url() . 'theme/images/' . $site_image ?>" />
    <link rel="stylesheet" href="<?php echo base_url() . 'theme/css/font-awesome.min.css' ?>" />
    <!-- End SEO Tag. -->
    <!-- fitur -->
    <!-- Animate.css -->
    <link rel="stylesheet" href="<?php echo base_url() . 'theme/css2/animate.css' ?>">
    <!-- Icomoon Icon Fonts-->
    <link rel="stylesheet" href="<?php echo base_url() . 'theme/css2/icomoon.css' ?>">
    <!-- Bootstrap  -->
    <link rel="stylesheet" href="<?php echo base_url() . 'theme/css2/bootstrap.css' ?>">
    <!-- Flexslider  -->
    <link rel="stylesheet" href="<?php echo base_url() . 'theme/css2/flexslider.css' ?>">
    <!-- Theme style  -->
    <link rel="stylesheet" href="<?php echo base_url() . 'theme/css2/style.css' ?>">
</head>

<body class="content-animate">

    <!-- PRELOADER
		==================================================-->
    <div class="page-loader">
        <div class="loader-area"></div>
        <div class="loader font-face1">loading...
        </div>
    </div>
    <!-- PAGE
		==================================================-->
    <div id="top" class="page">

        <!-- Navigation panel
			================================================== -->
        <?php echo $header; ?>
        <!-- End Navigation panel -->

        <!-- Main Content
			==================================================-->
        <main class="cd-main-content">

            <!-- HOME SECTION
				================================================== -->
            <section id="homepage" class="home page-section parallax-2 overlay-light-alpha-10" data-background="<?php echo base_url() . 'theme/images/' . $bg_header; ?>">
                <div class="table-content">
                    <div class="table-center-text">
                        <div class="container" align="right">
                            <h2 class="font-face1 heading1 fw700 mb-40 mb-xs-30"><?php echo $caption_1; ?></h2>
                            <h1 class="font-face1 heading2 fw700 mb-40 mb-xs-30"><?php echo $caption_2; ?></h1>
                            <div class="local-scroll">
                                <!--<a href="<?php echo site_url('pemesanan'); ?>" class="btn bg-black white-color">Pemesanan Sekarang</a>
								<span class="btn_seperator"></span>-->
                                <!--<a href="<?php echo site_url('blog'); ?>" class="btn bg-black whitre-color hidden-xs">Blog</a>-->
                            </div>
                            <!-- timer promo -->
                            <style scoped="scoped" type="text/css">
                                #countdownpenaindigo {
                                    background: ;
                                    color: white;
                                    font-family: Oswald, Arial, Sans-serif;
                                    font-size: 40px;
                                    text-transform: uppercase;
                                    text-align: left;
                                    margin-top: 500px;
                                    font-weight: normal;

                                }

                                .teks {
                                    color: black;
                                    font-size: 10px;
                                }

                                .posisi {
                                    position: relative;
                                }
                            </style>
                            <div id="countdownpenaindigo">
                                <h1 style="color: black;font-size: 13px;"><strong>Yuk buruan order promonya sebelum kehabisan!</strong></h1>
                                <span id="countdown"></span>&nbsp;
                                <a href="<?php echo site_url('hosting'); ?>" class="btn bg-black white-color ">Pesan Sekarang</a>
                                <span class="btn_seperator"></span>
                            </div>
                            <script type="text/javascript">
                                //<![CDATA[
                                // set the date we're counting down to
                                var target_date = new Date("Nov 1, 2020").getTime();
                                // variables for time units
                                var days, hours, minutes, seconds;
                                // get tag element
                                var countdown = document.getElementById("countdown");
                                // update the tag with id "countdown" every 1 second
                                setInterval(function() {
                                    // find the amount of "seconds" between now and target
                                    var current_date = new Date().getTime();
                                    var seconds_left = (target_date - current_date) / 1000;
                                    // do some time calculations
                                    days = parseInt(seconds_left / 86400);
                                    seconds_left = seconds_left % 86400;
                                    hours = parseInt(seconds_left / 3600);
                                    seconds_left = seconds_left % 3600;
                                    minutes = parseInt(seconds_left / 60);
                                    seconds = parseInt(seconds_left % 60);
                                    // format countdown string + set tag value

                                    countdown.innerHTML = days + " <span class='teks'>hari</span> " + hours + " <span class='teks'>jam</span> " +
                                        minutes + " <span class='teks'>menit</span> " + seconds + " <span class='teks'>detik </span>";
                                }, 1000);
                                //]]>
                            </script>
                        </div>
                    </div>
                </div>
            </section>
    </div>
    </div>
    </div>
    </section>


    <!-- paket DOMAIN -->
    <style>
        .jarak {
            margin-top: 50px;
            margin-bottom: 30px;
        }

        .coba {
            margin-bottom: 100px;
        }
    </style>
    <!-- feature_part start-->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/bootstrap.min.css">
    <!-- animate CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/animate.css">
    <!-- owl carousel CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/owl.carousel.min.css">
    <!-- themify CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/themify-icons.css">
    <!-- flaticon CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/flaticon.css">
    <!-- font awesome CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/font-awesome.min.css" />
    <!-- swiper CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/slick.css">
    <!-- style CSS -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/home/css/style.css">
    <section class="feature_part" id="pemesanan">
        <div class="container">
            <center>
                <div>
                    <div class="single_feature_text coba">
                        <h2>Pilih domain kesayangan anda</h2>
                        <!--<p>Fitur pelayanan dari kami yang dapat anda nikmati, agar rumah anda menjadi bersih dan nyaman. </p>-->
                        <!--<a href="#" class="btn_1">Read More</a>-->
                    </div>
            </center>

            <div class="col-sm-6 col-xl-3">
                <div class="single_feature">
                    <div class="single_feature_part">
                        <h4 style="color: blue;" align="left">.COM</h4>
                        <p>
                            Ekstensi nama domain paling populer
                        </p>
                        <h5>Rp. 147.500,-</h5>
                        <a href="domain/cek_domain" style=" text-align: center;font-size: 15px;margin-top: 30px;margin-bottom: 10px;" class="btn btn-outline-warning">PESAN SEKARANG</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="single_feature">
                    <div class="single_feature_part">
                        <h4 style="color: blue;" align="left">.NET</h4>
                        <p>
                            Buat nama domain unik dan kreatif tanpa batas
                        </p>
                        <h5>Rp. 180.500,-</h5>
                        <a href="domain/cek_domain" style=" text-align: center;font-size: 15px;margin-top: 30px;margin-bottom: 10px;" class="btn btn-outline-warning">PESAN SEKARANG</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="single_feature">
                    <div class="single_feature_part">
                        <h4 style="color: blue;" align="left">.ORG</h4>
                        <p>
                            Domain untuk organisasi, komunitas, atau lembaga
                        </p>
                        <h5>Rp. 202.500,-</h5>
                        <a href="domain/cek_domain" style=" text-align: center;font-size: 15px;margin-top: 30px;margin-bottom: 10px;" class="btn btn-outline-warning">PESAN SEKARANG</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="single_feature">
                    <div class="single_feature_part">
                        <h4 style="color: blue;" align="left">.CO.ID</h4>
                        <p>
                            Ekstensi nama domain untuk perusahaan/institusi
                        </p>
                        <h5>Rp. 312.500,-</h5>
                        <a href="domain/cek_domain" style=" text-align: center;font-size: 15px;margin-top: 30px;margin-bottom: 10px;" class="btn btn-outline-warning">PESAN SEKARANG</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="single_feature">
                    <div class="single_feature_part">
                        <h4 style="color: blue;" align="left">.SCH.ID</h4>
                        <p>
                            Ekstensi nama domain untuk sekolah atau perguruan tinggi
                        </p>
                        <h5>Rp. 70.500,-</h5>
                        <a href="domain/cek_domain" style=" text-align: center;font-size: 15px;margin-top: 30px;margin-bottom: 10px;" class="btn btn-outline-warning">PESAN SEKARANG</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="single_feature">
                    <div class="single_feature_part">
                        <h4 style="color: blue;" align="left">.SITE</h4>
                        <p>
                            Ekstensi nama domain untuk sekolah atau perguruan tinggi
                        </p>
                        <h5>Rp. 25.400,-</h5>
                        <a href="domain/cek_domain" style=" text-align: center;font-size: 15px;margin-top: 30px;margin-bottom: 10px;" class="btn btn-outline-warning">PESAN SEKARANG</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="single_feature">
                    <div class="single_feature_part">
                        <h4 style="color: blue;" align="left">.ID</h4>
                        <p>
                            Top Level Domain Indonesia untuk personal dan institusi di indonesia
                        </p>
                        <h5>Rp. 230.000,-</h5>
                        <a href="domain/cek_domain" style=" text-align: center;font-size: 15px;margin-top: 30px;margin-bottom: 10px;" class="btn btn-outline-warning">PESAN SEKARANG</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="single_feature">
                    <div class="single_feature_part">
                        <h4 style="color: blue;" align="left">.SITE</h4>
                        <p>
                            Tetap tunjukkan kesan profesional dengan domain ini
                        </p>
                        <h5>Rp. 25.400,-</h5>
                        <a href="domain/cek_domain" style=" text-align: center;font-size: 15px;margin-top: 30px;margin-bottom: 10px;" class="btn btn-outline-warning">PESAN SEKARANG</a>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <!-- end -->
    <div class="coba"></div>
    <!-- tabel DOMAIN -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">

    <div class="container">

        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Nama Domain</th>
                    <th>Harga</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $batas = 10;
                $halaman = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
                $halaman_awal = ($halaman > 1) ? ($halaman * $batas) - $batas : 0;

                $previous = $halaman - 1;
                $next = $halaman + 1;

                $data = mysqli_query($koneksi, "select * from tbl_domain");
                $jumlah_data = mysqli_num_rows($data);
                $total_halaman = ceil($jumlah_data / $batas);

                $data_pegawai = mysqli_query($koneksi, "select * from tbl_domain limit $halaman_awal, $batas");
                $nomor = $halaman_awal + 1;
                while ($d = mysqli_fetch_array($data_pegawai)) {
                ?>
                    <tr>
                        <td><?php echo $nomor++; ?></td>
                        <td><?php echo $d['nama_domain']; ?></td>
                        <td><?php echo $d['harga']; ?></td>

                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
        <nav>
            <ul class="pagination justify-content-center">
                <li class="page-item">
                    <a class="page-link" <?php if ($halaman > 1) {
                                                echo "href='?halaman=$Previous'";
                                            } ?>>Previous</a>
                </li>
                <?php
                for ($x = 1; $x <= $total_halaman; $x++) {
                ?>
                    <li class="page-item"><a class="page-link" href="?halaman=<?php echo $x ?>"><?php echo $x; ?></a></li>
                <?php
                }
                ?>
                <li class="page-item">
                    <a class="page-link" <?php if ($halaman < $total_halaman) {
                                                echo "href='?halaman=$next'";
                                            } ?>>Next</a>
                </li>
            </ul>
        </nav>
    </div>
    <!-- end -->


    <!-- SECTION SUBSCRIBE
				================================================== -->
    <section class="page-section subscribe-section small-section">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="form-subscribe mb-50 mb-sm-0">
                        <div class="col-sm-6 mb-sm-40">
                            <h2 class="heading5 mt-0 font-face1 white-color fw700 mb-0">Newsletter.</h2>
                        </div>
                        <div class="col-sm-6">
                            <form class="form-inline" action="<?php echo site_url('subscribe'); ?>" method="post">
                                <div class="form-group">
                                    <input type="hidden" name="url" value="<?php echo site_url(); ?>" required>
                                    <input type="email" name="email" required placeholder="Your Email..." class="form-control">
                                    <button type="submit" class="btn btn-subscribe">berlangganan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div><?php echo $this->session->flashdata('message'); ?></div>
                </div>
            </div>
        </div>
    </section>

    <!-- FOOTER
				================================================== -->
    <?php echo $footer; ?>

    </main>

    </div>

    <!-- Modal Search-->
    <div class="modal fade" id="ModalSearch" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="z-index: 10000;">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <form action="<?php echo site_url('search'); ?>" method="GET">
                        <div class="input-group">
                            <input type="text" name="search_query" class="form-control input-search" style="height: 40px;" placeholder="Search..." required>
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit" style="height: 40px;background-color: #ccc;"><span class="fa fa-search"></span></button>
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- JAVASCRIPT
		==================================================-->
    <script src="<?php echo base_url('theme/js/jquery-2.2.4.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/jquery.easing.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/waypoints.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/jquery.scrollTo.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/jquery.localScroll.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/jquery.viewport.mini.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/jquery.sticky.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/jquery.fitvids.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/jquery.parallax-1.1.3.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/isotope.pkgd.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/imagesloaded.pkgd.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/masonry.pkgd.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/jquery.magnific-popup.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/jquery.counterup.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/slick.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/wow.min.js') ?>"></script>
    <script src="<?php echo base_url('theme/js/script.js') ?>"></script>
</body>

</html>