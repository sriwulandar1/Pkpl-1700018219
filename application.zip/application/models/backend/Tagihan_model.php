<?php
class Tagihan_model extends CI_Model
{
	function validasi_aplikasi($id)
	{
		$hsl = $this->db->query("SELECT * FROM tbl_pemesanan_aplikasi WHERE id_pemesanan ='$id'");
		return $hsl;
	}
}
